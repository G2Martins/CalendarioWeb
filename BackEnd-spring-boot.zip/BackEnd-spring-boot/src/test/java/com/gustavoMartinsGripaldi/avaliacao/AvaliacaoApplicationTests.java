package com.gustavoMartinsGripaldi.avaliacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvaliacaoApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("✅ Teste de contexto executado com sucesso!");
	}

}
